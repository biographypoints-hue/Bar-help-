# Quick Switcher — Floating Taskbar

A draggable floating dock that auto-collects icons of recently used apps and lets you jump
back to any of them with one tap, without touching Home or Recents.

## Project structure

```
app/src/main/java/com/quickswitch/floatingtaskbar/
├── MainActivity.kt                       Control panel: ON/OFF switch + permission buttons
├── viewmodel/MainViewModel.kt             Persists the ON/OFF state (SharedPreferences)
├── model/AppTab.kt                        Data class for one dock icon
├── service/FloatingOverlayService.kt      Owns the overlay window: drag, snap, tabs, launch
├── service/AppDetectionAccessibilityService.kt   Detects the foreground app in real time
├── receiver/BootReceiver.kt               Restarts the dock after reboot if it was ON
└── util/                                  PermissionUtils, AppUtils, Constants

app/src/main/res/
├── layout/activity_main.xml               Main screen
├── layout/overlay_floating_bar.xml        The floating dock itself
├── layout/item_app_icon.xml               One circular icon + active-glow ring
├── drawable/                               Rounded dock background, active ring, icons
├── values/                                 Colors, strings, theme
└── xml/accessibility_service_config.xml    Accessibility service declaration
```

## How it works

1. **AppDetectionAccessibilityService** listens for `TYPE_WINDOW_STATE_CHANGED` accessibility
   events. Whenever the foreground package changes, it forwards the package name to the
   overlay service. It never reads screen content or performs actions — pure observation.
2. **FloatingOverlayService** is a foreground `Service` that adds a `WindowManager` overlay
   view to the screen. It keeps a list of up to 7 most-recently-used `AppTab`s, rebuilds the
   icon row whenever the list changes, and highlights whichever tab is currently active.
3. Tapping an icon calls `AppUtils.launchApp()`, which resolves the target app's launcher
   `Intent` and adds `FLAG_ACTIVITY_NEW_TASK | FLAG_ACTIVITY_REORDER_TO_FRONT` so Android
   brings the app's existing task to the front instead of restarting it.
4. Dragging is scoped to a small grip handle on the dock (not the icons themselves), so a
   normal tap never gets mistaken for a drag. On release, the dock animates to whichever
   screen edge (left/right/top/bottom) it ended up closest to.
5. Long-pressing an icon removes it from the dock (the app itself keeps running — this only
   removes the shortcut).

## Setup guide (Android Studio)

1. **Open the project**
   - Android Studio → *Open* → select the `FloatingTaskbar` folder.
   - Let Gradle sync. If prompted to create a Gradle wrapper, accept it (or install the
     Gradle version referenced in `gradle/wrapper/gradle-wrapper.properties`).
2. **SDK requirements**
   - `compileSdk`/`targetSdk` = 34, `minSdk` = 24 (Android 7.0+). Make sure SDK Platform 34
     is installed via *Tools → SDK Manager*.
3. **Run**
   - Connect a physical device or start an emulator (overlay/accessibility permissions
     behave most realistically on a physical device).
   - Click **Run ▶** to install and launch.
4. **(Optional) Replace the placeholder launcher icon**
   - The project ships a simple vector app icon (`drawable/ic_launcher_foreground.xml`) so it
     compiles out of the box. For a polished icon, right-click `res` → *New → Image Asset* and
     regenerate proper mipmap launcher icons.

## End-user guide

### Turning the dock ON / OFF
- Open **Quick Switcher** → flip the switch at the top of the screen.
- The status line reads **"Service Running"** (green) when the dock is active, or
  **"Service Stopped"** (red) otherwise.
- Turning it OFF immediately removes the floating dock from the screen.

### Granting permissions (required once)
The switch cannot be turned ON until both permissions below are granted:

1. **Grant Overlay Permission** — opens *"Display over other apps"* settings for this app.
   Toggle it on, then press back to return.
2. **Enable Accessibility Service** — opens system *Accessibility* settings. Find
   **Quick Switcher** in the list, tap it, and enable it. This is what lets the dock notice
   which app you've switched to; it does not read any on-screen content.

Each button turns into **"Granted ✓"** once its permission is active.

### Using the floating dock
- **Automatic tabs** — as you open apps, their icons appear in the dock automatically.
- **Switch apps** — tap any icon to jump straight back to that app.
- **Active indicator** — the icon of whatever app is currently in front shows a glowing ring.
- **Remove a tab** — long-press an icon to remove its shortcut from the dock (the app itself
  keeps running in the background as normal).
- **Move the dock** — press and drag the small grip (the three lines) on the left edge of the
  dock; release near any screen edge and it snaps neatly into place.
- **Scrolling** — once more than ~5 apps are tracked, swipe left/right along the dock to see
  the rest (it holds up to 7 at a time; the oldest is dropped automatically).
