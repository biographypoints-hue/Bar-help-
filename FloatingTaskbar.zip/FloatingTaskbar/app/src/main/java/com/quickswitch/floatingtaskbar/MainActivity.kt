package com.quickswitch.floatingtaskbar

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.Snackbar
import com.quickswitch.floatingtaskbar.databinding.ActivityMainBinding
import com.quickswitch.floatingtaskbar.service.FloatingOverlayService
import com.quickswitch.floatingtaskbar.util.PermissionUtils
import com.quickswitch.floatingtaskbar.viewmodel.MainViewModel

/**
 * Single control-panel screen: shows whether both required permissions are
 * granted, and hosts the master ON/OFF switch that starts or stops
 * [FloatingOverlayService].
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
        observeViewModel()
        refreshPermissionUi()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionUi()
        // If the user just came back from granting a permission in Settings
        // and the toggle was already ON, start the dock automatically.
        if (viewModel.isServiceEnabled.value == true && allPermissionsGranted()) {
            startDockService()
        }
    }

    private fun setupListeners() {
        binding.switchServiceToggle.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!allPermissionsGranted()) {
                    binding.switchServiceToggle.isChecked = false
                    Snackbar.make(
                        binding.root,
                        getString(R.string.error_missing_permissions),
                        Snackbar.LENGTH_LONG
                    ).show()
                    return@setOnCheckedChangeListener
                }
                viewModel.setServiceEnabled(true)
                startDockService()
            } else {
                viewModel.setServiceEnabled(false)
                stopDockService()
            }
            updateStatusText()
        }

        binding.btnGrantOverlay.setOnClickListener {
            PermissionUtils.requestOverlayPermission(this)
        }

        binding.btnGrantAccessibility.setOnClickListener {
            PermissionUtils.requestAccessibilityPermission(this)
        }
    }

    private fun observeViewModel() {
        viewModel.isServiceEnabled.observe(this) { enabled ->
            binding.switchServiceToggle.isChecked = enabled
            updateStatusText()
        }
    }

    private fun refreshPermissionUi() {
        val overlayGranted = PermissionUtils.canDrawOverlays(this)
        val accessibilityGranted = PermissionUtils.isAccessibilityServiceEnabled(this)

        binding.btnGrantOverlay.text = if (overlayGranted)
            getString(R.string.permission_granted) else getString(R.string.grant_overlay_permission)
        binding.btnGrantOverlay.isEnabled = !overlayGranted

        binding.btnGrantAccessibility.text = if (accessibilityGranted)
            getString(R.string.permission_granted) else getString(R.string.grant_accessibility_permission)
        binding.btnGrantAccessibility.isEnabled = !accessibilityGranted

        updateStatusText()
    }

    private fun allPermissionsGranted(): Boolean =
        PermissionUtils.canDrawOverlays(this) && PermissionUtils.isAccessibilityServiceEnabled(this)

    private fun updateStatusText() {
        val running = viewModel.isServiceEnabled.value == true && allPermissionsGranted()
        binding.tvStatus.text =
            if (running) getString(R.string.status_running) else getString(R.string.status_stopped)
        binding.tvStatus.setTextColor(
            getColor(if (running) R.color.status_running else R.color.status_stopped)
        )
    }

    private fun startDockService() {
        val intent = Intent(this, FloatingOverlayService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopDockService() {
        stopService(Intent(this, FloatingOverlayService::class.java))
    }
}
