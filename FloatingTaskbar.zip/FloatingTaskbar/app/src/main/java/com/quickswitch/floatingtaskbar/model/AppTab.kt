package com.quickswitch.floatingtaskbar.model

import android.graphics.drawable.Drawable

/**
 * Represents a single running-app shortcut shown inside the floating dock.
 */
data class AppTab(
    val packageName: String,
    val label: String,
    val icon: Drawable,
    var lastActiveTimestamp: Long = System.currentTimeMillis(),
    var isActive: Boolean = false
)
