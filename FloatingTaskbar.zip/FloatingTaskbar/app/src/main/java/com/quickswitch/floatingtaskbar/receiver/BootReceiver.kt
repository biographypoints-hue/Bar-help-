package com.quickswitch.floatingtaskbar.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.quickswitch.floatingtaskbar.service.FloatingOverlayService
import com.quickswitch.floatingtaskbar.util.Constants
import com.quickswitch.floatingtaskbar.util.PermissionUtils

/**
 * Restarts the floating dock after a reboot, but only if the user had it
 * switched ON and both permissions are still granted.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        val wasEnabled = prefs.getBoolean(Constants.KEY_SERVICE_ENABLED, false)
        if (!wasEnabled) return
        if (!PermissionUtils.canDrawOverlays(context)) return
        if (!PermissionUtils.isAccessibilityServiceEnabled(context)) return

        ContextCompat.startForegroundService(context, Intent(context, FloatingOverlayService::class.java))
    }
}
