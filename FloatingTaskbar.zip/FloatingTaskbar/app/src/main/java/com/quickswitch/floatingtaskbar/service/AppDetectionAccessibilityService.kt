package com.quickswitch.floatingtaskbar.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.quickswitch.floatingtaskbar.util.AppUtils
import com.quickswitch.floatingtaskbar.util.Constants

/**
 * Lightweight AccessibilityService whose only job is to notice when the
 * foreground window changes and forward the new package name to
 * [FloatingOverlayService]. It never reads view contents, clicks anything,
 * or performs any action beyond observation of which app is in front.
 */
class AppDetectionAccessibilityService : AccessibilityService() {

    private var lastReportedPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString() ?: return
        if (packageName == lastReportedPackage) return
        if (!AppUtils.isLaunchableApp(this, packageName)) return

        lastReportedPackage = packageName
        Log.d(TAG, "Foreground app changed -> $packageName")

        val intent = Intent(this, FloatingOverlayService::class.java).apply {
            action = Constants.ACTION_APP_FOREGROUND_CHANGED
            putExtra(Constants.EXTRA_PACKAGE_NAME, packageName)
        }
        try {
            startService(intent)
        } catch (e: IllegalStateException) {
            // Some OEMs restrict background service starts; harmless to miss a tick.
            Log.w(TAG, "Could not forward foreground app: ${e.message}")
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted")
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "Accessibility service connected")
    }

    companion object {
        private const val TAG = "AppDetectionA11yService"
    }
}
