package com.quickswitch.floatingtaskbar.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.app.NotificationCompat
import com.quickswitch.floatingtaskbar.MainActivity
import com.quickswitch.floatingtaskbar.R
import com.quickswitch.floatingtaskbar.model.AppTab
import com.quickswitch.floatingtaskbar.util.AppUtils
import com.quickswitch.floatingtaskbar.util.Constants
import kotlin.math.abs

/**
 * Foreground service that owns the floating dock window: creating it,
 * handling drag + edge-snap gestures, and keeping its list of app tabs in
 * sync with whichever app is currently in the foreground.
 */
class FloatingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var dockView: View? = null
    private lateinit var iconContainer: LinearLayout
    private lateinit var scrollView: HorizontalScrollView
    private lateinit var dragHandle: View
    private lateinit var layoutParams: WindowManager.LayoutParams

    private val tabs = mutableListOf<AppTab>()
    private var currentActivePackage: String? = null

    // --- drag gesture state ---
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createDockView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == Constants.ACTION_APP_FOREGROUND_CHANGED) {
            val packageName = intent.getStringExtra(Constants.EXTRA_PACKAGE_NAME)
            if (!packageName.isNullOrEmpty()) {
                onForegroundAppChanged(packageName)
            }
        }
        // START_STICKY: if the OS kills this service under memory pressure,
        // it is recreated (without the extras) so the dock reappears.
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        dockView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: IllegalArgumentException) {
                // View was already detached from the window manager; nothing to do.
            }
        }
        dockView = null
    }

    // ------------------------------------------------------------------
    // Dock window setup
    // ------------------------------------------------------------------

    private fun createDockView() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_floating_bar, null)
        dockView = view

        iconContainer = view.findViewById(R.id.iconContainer)
        scrollView = view.findViewById(R.id.scrollView)
        dragHandle = view.findViewById(R.id.dragHandle)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 600
        }

        setupDragTouchListener()
        windowManager.addView(dockView, layoutParams)
    }

    /**
     * Only the small grip handle starts a drag gesture, so a normal tap on
     * any app icon is never accidentally hijacked into a move.
     */
    private fun setupDragTouchListener() {
        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isDragging = false
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > TOUCH_SLOP || abs(dy) > TOUCH_SLOP) {
                        isDragging = true
                    }
                    if (isDragging) {
                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy
                        safeUpdateViewLayout()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isDragging) snapToNearestEdge()
                    true
                }
                else -> false
            }
        }
    }

    private fun safeUpdateViewLayout() {
        dockView?.let {
            try {
                windowManager.updateViewLayout(it, layoutParams)
            } catch (e: IllegalArgumentException) {
                Log.w(TAG, "updateViewLayout failed: ${e.message}")
            }
        }
    }

    /** Animates the dock to whichever screen edge (L/R/T/B) it's currently closest to. */
    private fun snapToNearestEdge() {
        val view = dockView ?: return
        val metrics = resources.displayMetrics
        val screenWidth = metrics.widthPixels
        val screenHeight = metrics.heightPixels

        val viewWidth = view.width.takeIf { it > 0 } ?: 300
        val viewHeight = view.height.takeIf { it > 0 } ?: 150

        val distLeft = layoutParams.x
        val distRight = screenWidth - (layoutParams.x + viewWidth)
        val distTop = layoutParams.y
        val distBottom = screenHeight - (layoutParams.y + viewHeight)
        val minDist = minOf(distLeft, distRight, distTop, distBottom)

        val targetX: Int
        val targetY: Int
        when (minDist) {
            distLeft -> {
                targetX = 0
                targetY = layoutParams.y.coerceIn(0, (screenHeight - viewHeight).coerceAtLeast(0))
            }
            distRight -> {
                targetX = screenWidth - viewWidth
                targetY = layoutParams.y.coerceIn(0, (screenHeight - viewHeight).coerceAtLeast(0))
            }
            distTop -> {
                targetX = layoutParams.x.coerceIn(0, (screenWidth - viewWidth).coerceAtLeast(0))
                targetY = 0
            }
            else -> {
                targetX = layoutParams.x.coerceIn(0, (screenWidth - viewWidth).coerceAtLeast(0))
                targetY = screenHeight - viewHeight
            }
        }
        animateDockTo(targetX, targetY)
    }

    private fun animateDockTo(targetX: Int, targetY: Int) {
        val startX = layoutParams.x
        val startY = layoutParams.y
        val animator = android.animation.ValueAnimator.ofFloat(0f, 1f)
        animator.duration = 260
        animator.interpolator = OvershootInterpolator(0.9f)
        animator.addUpdateListener { anim ->
            val fraction = anim.animatedValue as Float
            layoutParams.x = (startX + (targetX - startX) * fraction).toInt()
            layoutParams.y = (startY + (targetY - startY) * fraction).toInt()
            safeUpdateViewLayout()
        }
        animator.start()
    }

    // ------------------------------------------------------------------
    // Tab management
    // ------------------------------------------------------------------

    private fun onForegroundAppChanged(packageName: String) {
        currentActivePackage = packageName

        val existing = tabs.find { it.packageName == packageName }
        if (existing != null) {
            existing.lastActiveTimestamp = System.currentTimeMillis()
        } else {
            val icon = AppUtils.getAppIcon(this, packageName) ?: return
            val label = AppUtils.getAppLabel(this, packageName)
            tabs.add(AppTab(packageName, label, icon))
            trimOldestTabsIfNeeded()
        }
        refreshActiveStates()
        rebuildIconViews(animateNewest = existing == null)
    }

    /** Keeps the dock bounded to the most recently used [Constants.MAX_VISIBLE_TABS] apps. */
    private fun trimOldestTabsIfNeeded() {
        if (tabs.size <= Constants.MAX_VISIBLE_TABS) return
        tabs.sortByDescending { it.lastActiveTimestamp }
        while (tabs.size > Constants.MAX_VISIBLE_TABS) {
            tabs.removeAt(tabs.size - 1)
        }
    }

    private fun refreshActiveStates() {
        tabs.forEach { it.isActive = (it.packageName == currentActivePackage) }
    }

    private fun rebuildIconViews(animateNewest: Boolean) {
        iconContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        val sortedTabs = tabs.sortedByDescending { it.lastActiveTimestamp }

        sortedTabs.forEachIndexed { index, tab ->
            val iconView = inflater.inflate(R.layout.item_app_icon, iconContainer, false)
            iconView.tag = tab.packageName

            val imageView = iconView.findViewById<ImageView>(R.id.iconImage)
            val activeRing = iconView.findViewById<View>(R.id.activeRing)

            imageView.setImageDrawable(tab.icon)
            activeRing.visibility = if (tab.isActive) View.VISIBLE else View.INVISIBLE

            iconView.setOnClickListener { AppUtils.launchApp(this, tab.packageName) }
            iconView.setOnLongClickListener {
                removeTab(tab.packageName)
                true
            }

            iconContainer.addView(iconView)

            if (animateNewest && index == 0) {
                iconView.scaleX = 0f
                iconView.scaleY = 0f
                iconView.animate()
                    .scaleX(1f).scaleY(1f)
                    .setDuration(220)
                    .setInterpolator(OvershootInterpolator())
                    .start()
            }
        }

        // Auto-scroll so the most recently added icon is visible.
        scrollView.post { scrollView.fullScroll(HorizontalScrollView.FOCUS_RIGHT) }
    }

    /** Long-press on a tab removes it from the dock (does not close the actual app). */
    private fun removeTab(packageName: String) {
        tabs.removeAll { it.packageName == packageName }
        rebuildIconViews(animateNewest = false)
    }

    // ------------------------------------------------------------------
    // Foreground notification (required to keep a long-running service alive)
    // ------------------------------------------------------------------

    private fun startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Floating Dock", NotificationManager.IMPORTANCE_MIN
            ).apply { description = "Keeps the floating quick-switch dock active" }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Quick Switcher active")
            .setContentText("Tap to open the app")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        private const val TAG = "FloatingOverlayService"
        private const val CHANNEL_ID = "floating_dock_channel"
        private const val NOTIFICATION_ID = 1001
        private const val TOUCH_SLOP = 12
    }
}
