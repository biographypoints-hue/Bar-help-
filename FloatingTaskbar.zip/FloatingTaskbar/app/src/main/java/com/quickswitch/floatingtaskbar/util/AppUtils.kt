package com.quickswitch.floatingtaskbar.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable

/** Small helpers around PackageManager so callers never touch it directly. */
object AppUtils {

    fun getAppLabel(context: Context, packageName: String): String {
        return try {
            val pm = context.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            packageName
        }
    }

    fun getAppIcon(context: Context, packageName: String): Drawable? {
        return try {
            context.packageManager.getApplicationIcon(packageName)
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    /** True if the package is a normal, user-launchable app (not our own app / system UI). */
    fun isLaunchableApp(context: Context, packageName: String): Boolean {
        if (packageName == context.packageName) return false
        if (Constants.IGNORED_PACKAGES.contains(packageName)) return false
        return context.packageManager.getLaunchIntentForPackage(packageName) != null
    }

    /** Brings the target app's existing task to the front (or starts a fresh one). */
    fun launchApp(context: Context, packageName: String) {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return
        launchIntent.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        )
        context.startActivity(launchIntent)
    }
}
