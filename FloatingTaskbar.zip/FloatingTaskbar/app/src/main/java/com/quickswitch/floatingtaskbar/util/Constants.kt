package com.quickswitch.floatingtaskbar.util

/**
 * Central place for shared-pref keys, intent actions and tunable limits so
 * nothing is duplicated (and typo'd differently) across files.
 */
object Constants {
    const val PREFS_NAME = "floating_taskbar_prefs"
    const val KEY_SERVICE_ENABLED = "service_enabled"

    const val ACTION_APP_FOREGROUND_CHANGED =
        "com.quickswitch.floatingtaskbar.ACTION_APP_FOREGROUND_CHANGED"
    const val EXTRA_PACKAGE_NAME = "extra_package_name"

    /** Hard cap on how many app tabs the dock keeps around at once. */
    const val MAX_VISIBLE_TABS = 7

    /** Packages that should never show up as a dock tab (launcher/system UI, etc.). */
    val IGNORED_PACKAGES = setOf(
        "com.android.systemui",
        "android"
    )
}
