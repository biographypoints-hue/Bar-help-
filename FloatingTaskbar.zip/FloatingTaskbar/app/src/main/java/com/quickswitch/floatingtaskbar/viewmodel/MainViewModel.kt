package com.quickswitch.floatingtaskbar.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.quickswitch.floatingtaskbar.util.Constants

/**
 * Holds the single piece of state MainActivity cares about: is the dock
 * supposed to be running. Persisted so BootReceiver can restore it, and so
 * the switch reflects reality even if the activity process was killed.
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

    private val _isServiceEnabled =
        MutableLiveData(prefs.getBoolean(Constants.KEY_SERVICE_ENABLED, false))
    val isServiceEnabled: LiveData<Boolean> = _isServiceEnabled

    fun setServiceEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(Constants.KEY_SERVICE_ENABLED, enabled).apply()
        _isServiceEnabled.value = enabled
    }
}
